#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "defns.h"
#pragma warning(disable: 4996) // for Visual Studio Only

int tr = 1;
int num_years = 0;
int damages_size = 0;
int fatality_size = 0;

int compare_damages(struct damage d1, struct damage d2);
int compare_deaths(struct deaths d1, struct deaths d2);
int compare_storms(struct storm_event d1, struct storm_event d2);
int compare_fatality(struct fatality_event d1, struct fatality_event d2);

int countLines(char* fileName);
int getTotalNoOfRec();
int convertCurrency(char* tok);

struct deaths* get_fatality_result_set(char* year_str, char* sort_type);
struct damage* get_damage_result_set(char* year_str, char* attr_str, char* sort_type);

struct fatality_event getFatalityEvent(int event_id, int year);
struct annual_storm* stormList;

void readQuery(struct annual_storm stormList[]);
void executeQuery(char* rec_no, char* year_str, char* attr_str, char* sort_type);
void print_damages(struct damage* damages, int tot_rec);
void flushStdIn();

void insert_sort_damages(struct damage* damages, int num_damage_rec);
void insert_sort_fatality(struct deaths* fatality, int num_deaths_rec);
void insert_sort_storms(struct storm_event* storms, int num_storm_rec);
void insert_sort_fatality_event(struct fatality_event* fatality, int num_fatality_rec);

void loadStormData(char* stormFileName, int count, struct storm_event stormEventsList[]);
void primary_sort(struct storm_event* storms, int num_storm_rec);

void printStorm_short(struct storm_event* storms, int num_storm_rec);
void printStorm(struct storm_event* storms, int num_storm_rec);
void printFatality(struct fatality_event* fatality, int num_fatality_rec);

void loadFatalityData(char* fatalityFile, int count, struct fatality_event fatalityEventsList[]);
void loadAnnualStorm(char* year_str, struct annual_storm* annualStormTemp);

void merge_storm(struct storm_event* arrObj, int l, int m, int r);
void merge_sort_storm(struct storm_event* arrObj, int p, int r);
void merge_damages(struct damage* arrObj, int l, int m, int r);
void merge_sort_damages(struct damage* arrObj, int p, int r);
void merge_fatality(struct deaths* arrObj, int l, int m, int r);
void merge_sort_fatality(struct deaths* arrObj, int p, int r);
void merge_fatality_event(struct fatality_event* arrObj, int l, int m, int r);
void merge_sort_fatality_event(struct fatality_event* arrObj, int p, int r);

void readQuery(struct annual_storm stormList[])
{
	if (tr > 0) printf("INSIDE readQuery\n");
	char* querylinestr = NULL;

	size_t lenth = 0;
	ssize_t nchr = 0;

	nchr = getline(&querylinestr, &lenth, stdin);
	int num_query = atoi(querylinestr);

	if (tr > 0)
	{
		printf("INSIDE readQuery....2\n");
	}

	if (tr > 0)
	{
		printf("INSIDE readQuery....3\n");
	}

	if (nchr < 0)
	{
		printf("no query file");
		return;
	}

	if (tr > 0)
	{
		printf("First Line in stdin : %s", querylinestr);
	}
	
	for (int a = 0; a < num_query; a++)
	{
		querylinestr = NULL;
		getline(&querylinestr, &lenth, stdin);

		if (tr > 0)
		{
			printf("%dth line in stdin : %s", a + 2, querylinestr);
		}

		char* token = strtok(querylinestr, " ");

		char* qry_str = token;
		token = strtok(NULL, " ");

		char* rec_no = token;
		token = strtok(NULL, " ");

		char* year_str = token;
		token = strtok(NULL, " ");

		char* attr_str = token;
		token = strtok(NULL, " ");

		char* sort_type = token;
		executeQuery(rec_no, year_str, attr_str, sort_type);

	}
	free(querylinestr);
}

void executeQuery(char* rec_no, char* year_str, char* attr_str, char* sort_type)
{
	if (tr > 0)
	{
		printf("rec_no:%s :: year_str:%s :: attr_str:%s :: sort_type:%s \n", rec_no, year_str, attr_str, sort_type);
	}

	if (strcmp(attr_str, "damage_property") >= 0 || strcmp(attr_str, "damage_crops") >= 0)
	{
		if (tr > 0)
		{
			printf("create damage struct\n");
		}

		struct damage* damages = get_damage_result_set(year_str, attr_str, sort_type);

		int sub_rec_cnt = 1;
		struct storm_event* storms_sublist;

		if (tr > 0)
		{
			printf("isMin :%d  :::: isMax :%d ::: neither\n", strcmp(rec_no, "min"), strcmp(rec_no, "max"));
		}

		if (strcmp(rec_no, "min") >= 0)
		{
			while (damages[0].damage_amount == damages[sub_rec_cnt].damage_amount)
			{
				sub_rec_cnt++;
			}
			storms_sublist = (struct storm_event*)malloc(sizeof(struct storm_event*) * sub_rec_cnt);

			for (int a = 0; a < sub_rec_cnt; a++) 
			{
				for (int b = 0; b < num_years; b++)
				{
					if (damages[a].year == stormList[b].year) {
						storms_sublist[a] = stormList[b].storm_events[damages[a].index];
						break;
					}
				}
			}

			if (strcmp(sort_type, "insertion") >= 0)
			{

				insert_sort_storms(storms_sublist, sub_rec_cnt);
			}
			else
			{

				merge_sort_storm(storms_sublist, 1, sub_rec_cnt);
			}
		}

		else if (strcmp(rec_no, "max") >= 0)
		{
			int len_damages = damages_size;

			if (tr > 0)
			{
				printf("damages length: %d", len_damages);
			}

			while (damages[len_damages - 1].damage_amount == damages[len_damages - 1 - sub_rec_cnt].damage_amount)
			{
				sub_rec_cnt++;
			}

			if (tr > 0) printf("No of MAX records :%d\n", sub_rec_cnt);

			storms_sublist = (struct storm_event*)malloc(sizeof(struct storm_event*) * sub_rec_cnt);

			for (int a = 0; a < sub_rec_cnt; a++) 
			{
				for (int b = 0; b < num_years; b++)
				{
					if (damages[len_damages - 1 - a].year == stormList[b].year) {
						storms_sublist[a] = stormList[b].storm_events[damages[len_damages - 1 - a].index];
						break;
					}
				}
			}

			if (strcmp(sort_type, "insertion") >= 0)
			{

				insert_sort_storms(storms_sublist, sub_rec_cnt);
			}

			else
			{

				merge_sort_storm(storms_sublist, 1, sub_rec_cnt);
			}
		}

		else
		{
			free(storms_sublist);
			storms_sublist = (struct storm_event*)malloc(sizeof(struct storm_event*) * 1);
			int rec_idx = atoi(rec_no);

			for (int b = 0; b < num_years; b++)
			{
				if (tr > 0)
				{
					printf("rec_idx : %d ::: year : %d ::: index : %d\n", rec_idx, damages[rec_idx].year, damages[rec_idx].index);
				}

				if (damages[rec_idx].year == stormList[b].year) 
				{
					if (tr > 0)
					{
						printf("rec_idx : %d ::: year : %d ::: index : %d\n", rec_idx, damages[rec_idx].year, damages[rec_idx].index);
					}

					storms_sublist[0] = stormList[b].storm_events[damages[rec_idx].index];
					break;
				}
			}
		}

		printStorm(storms_sublist, sub_rec_cnt);
		free(storms_sublist);
	}

	else
	{

		if (tr > 0)
		{
			printf("create death struct\n");
		}

		struct deaths* death_list = get_fatality_result_set(year_str, sort_type);

		int sub_rec_cnt = 1;
		struct fatality_event* fatality_sublist;

		if (tr > 0)
		{
			printf("isMin :%d  :::: isMax :%d ::: neither\n", strcmp(rec_no, "min"), strcmp(rec_no, "max"));
		}

		if (strcmp(rec_no, "min") >= 0)
		{
			while (death_list[0].total_deaths == death_list[sub_rec_cnt].total_deaths)
			{
				sub_rec_cnt++;
			}

			fatality_sublist = (struct fatality_event*)malloc(sizeof(struct fatality_event*) * sub_rec_cnt);

			for (int a = 0; a < sub_rec_cnt; a++)
			{
				for (int b = 0; b < num_years; b++)
				{
					if (death_list[a].year == stormList[b].year)
					{
						int event_id = stormList[b].storm_events[death_list[a].index].event_id;
						fatality_sublist[a] = getFatalityEvent(event_id, death_list[a].year);

						break;
					}
				}
			}
			if (strcmp(sort_type, "insertion") >= 0)
			{

				insert_sort_fatality_event(fatality_sublist, sub_rec_cnt);
			}
			else
			{

				merge_sort_fatality_event(fatality_sublist, 1, sub_rec_cnt);
			}
		}

		else if (strcmp(rec_no, "max") >= 0)
		{
			int len_deaths = fatality_size;
			if (tr > 0)
			{
				printf("deaths length: %d", len_deaths);
			}

			while (death_list[len_deaths - 1].total_deaths == death_list[len_deaths - 1 - sub_rec_cnt].total_deaths)
			{
				sub_rec_cnt++;
			}

			if (tr > 0)
			{
				printf("No of MAX records :%d\n", sub_rec_cnt);
			}

			fatality_sublist = (struct fatality_event*)malloc(sizeof(struct fatality_event*) * sub_rec_cnt);

			for (int a = 0; a < sub_rec_cnt; a++)
			{
				for (int b = 0; b < num_years; b++)
				{
					if (death_list[len_deaths - 1 - a].year == stormList[b].year) {
						int eventId = stormList[b].storm_events[death_list[len_deaths - 1 - a].index].event_id;
						fatality_sublist[a] = getFatalityEvent(eventId, death_list[len_deaths - 1 - a].year);
						break;
					}
				}
			}

			if (strcmp(sort_type, "insertion") >= 0)
			{

				insert_sort_fatality_event(fatality_sublist, sub_rec_cnt);
			}
			else
			{

				merge_sort_fatality_event(fatality_sublist, 1, sub_rec_cnt);
			}
		}

		else
		{
			fatality_sublist = (struct fatality_event*)malloc(sizeof(struct fatality_event*) * 1);
			int rec_idx = atoi(rec_no);

			for (int b = 0; b < num_years; b++)
			{
				if (tr > 0)
				{
					printf("rec_idx : %d ::: year : %d ::: index : %d\n", rec_idx, death_list[rec_idx].year, death_list[rec_idx].index);
				}

				if (death_list[rec_idx].year == stormList[b].year) 
				{
					if (tr > 0)
					{
						printf("rec_idx : %d ::: year : %d ::: index : %d\n", rec_idx, death_list[rec_idx].year, death_list[rec_idx].index);
					}

					int eId = stormList[b].storm_events[death_list[rec_idx].index].event_id;
					fatality_sublist[0] = getFatalityEvent(eId, stormList[b].storm_events[death_list[rec_idx].index].year);
					break;
				}
			}
		}

	}

}

struct deaths* get_fatality_result_set(char* year_str, char* sort_type)
{
	struct deaths* fatalities;
	if (strcmp(year_str, "all") >= 0)
	{
		fatality_size = getTotalNoOfRec();
		fatalities = (struct deaths*)malloc(sizeof(struct deaths*) * fatality_size);
		int idx = 0;
		for (int a = 0; a < num_years; a++)
		{
			int storm_recs = stormList[a].no_storms;
			for (int b = 0; b < storm_recs; b++)
			{
				fatalities[idx].total_deaths = stormList[a].storm_events[b].deaths_direct + stormList[a].storm_events[b].deaths_indirect;

				fatalities[idx].year = stormList[a].storm_events[b].year;
				fatalities[idx].index = b;
			}

			idx++;
		}
	}

	else
	{
		int year_int = atoi(year_str);

		for (int a = 0; a < num_years; a++)
		{
			if (year_int == stormList[a].year)
			{
				int storm_recs = stormList[a].no_storms;
				fatality_size = storm_recs;
				fatalities = (struct deaths*)malloc(sizeof(struct deaths*) * storm_recs);

				for (int b = 0; b < storm_recs; b++)
				{
					fatalities[b].total_deaths = stormList[a].storm_events[b].deaths_direct + stormList[a].storm_events[b].deaths_indirect;
					fatalities[b].year = stormList[a].storm_events[b].year;
					fatalities[b].index = b;
				}
			}
		}
	}

	if (strcmp(sort_type, "insertion") >= 0)
	{

		insert_sort_fatality(fatalities, fatality_size);
	}

	else
	{

		merge_sort_fatality(fatalities, 1, fatality_size);

	}

	return fatalities;
}

struct damage* get_damage_result_set(char* year_str, char* attr_str, char* sort_type)
{
	struct damage* damages;

	if (strcmp(year_str, "all") >= 0)
	{
		damages_size = getTotalNoOfRec();
		damages = (struct damage*)malloc(sizeof(struct damage*) * damages_size);
		int idx = 0;

		for (int a = 0; a < num_years; a++)
		{
			int storm_recs = stormList[a].no_storms;

			for (int b = 0; b < storm_recs; b++)
			{
				if (strcmp(attr_str, "damage_property") >= 0) 
				{
					damages[idx].damage_amount = stormList[a].storm_events[b].damage_property;

				}
				else
				{
					damages[idx].damage_amount = stormList[a].storm_events[b].damage_crops;
				}

				damages[idx].year = stormList[a].storm_events[b].year;
				damages[idx].index = b;
			}
			idx++;
		}

	}
	else
	{
		int year_int = atoi(year_str);
		for (int a = 0; a < num_years; a++)
		{
			if (year_int == stormList[a].year)
			{
				int storm_recs = stormList[a].no_storms;
				damages_size = storm_recs;
				damages = (struct damage*)malloc(sizeof(struct damage*) * storm_recs);

				for (int b = 0; b < storm_recs; b++)
				{
					if (strcmp(attr_str, "damage_property") >= 0) {
						damages[b].damage_amount = stormList[a].storm_events[b].damage_property;
					}
					else
					{
						damages[b].damage_amount = stormList[a].storm_events[b].damage_crops;
					}
					damages[b].year = stormList[a].storm_events[b].year;
					damages[b].index = b;
				}
			}
		}
	}

	if (strcmp(sort_type, "insertion") >= 0)
	{

		insert_sort_damages(damages, damages_size);

	}
	else
	{
		merge_sort_damages(damages, 1, damages_size);

	}

	return damages;
}

void print_damages(struct damage* damages, int tot_rec)
{
	for (int a = 0; a < tot_rec; a++) 
	{
		printf("%d ::: %d ::: %d\n", damages[a].damage_amount, damages[a].year, damages[a].index);
	}
}

void flushStdIn()
{
	char c;
	do c = getchar();
	while (c != '\n' && c != EOF);
}

int compare_damages(struct damage d1, struct damage d2)
{
	int a = -1;
	if (d1.damage_amount > d2.damage_amount)
	{
		return 1;
	}

	else if 
	{
		(d1.damage_amount < d2.damage_amount) return -1;
	}

	else
	{
		if (d1.year > d2.year)
		{
			return 1;
		}

		else if (d1.year < d2.year)
		{
			return -1;
		}

		else
		{
			if (d1.index > d2.index)
			{
				return 1;
			}

			else return -1;
		}
	}
	return a;
}

int compare_deaths(struct deaths d1, struct deaths d2)
{
	int a = -1;

	if (d1.total_deaths > d2.total_deaths)
	{
		return 1;
	}

	else if (d1.total_deaths < d2.total_deaths)
	{
		return -1;
	}

	else
	{
		if (d1.year > d2.year)
		{
			return 1;
		}

		else if (d1.year < d2.year)
		{
			return -1;
		}

		else
		{
			if (d1.index > d2.index) return 1;
			else return -1;
		}
	}
	return a;
}

int compare_storms(struct storm_event d1, struct storm_event d2)
{
	int a = -1;
	if (d1.year > d2.year)
	{
		return 1;
	}

	else if (d1.year < d2.year)
	{
		return -1;
	}

	else
	{
		if (d1.event_id > d2.event_id)
		{
			return 1;
		}

		else return -1;
	}
	return a;
}

int compare_fatality(struct fatality_event d1, struct fatality_event d2)
{
	int a = -1;
	if (d1.event_id > d2.event_id) return 1;
	else return -1;
	return a;
}

void insert_sort_damages(struct damage* damages, int num_damage_rec)
{
	if (tr > 0) printf("INSIDE insert_sort_damages:: num_damage_rec : %d\n", num_damage_rec);
	int i, j;
	struct damage key;

	for (i = 1; i < num_damage_rec; i++)
	{
		key = damages[i];
		j = i - 1;

		while (j >= 0 && compare_damages(damages[j], key) > 0)
		{
			damages[j + 1] = damages[j];
			j = j - 1;
		}
		damages[j + 1] = key;
	}
}

void insert_sort_fatality(struct deaths* fatality, int num_deaths_rec)
{
	if (tr > 0)
	{
		printf("INSIDE insert_sort_fatality:: num_deaths_rec : %d\n", num_deaths_rec);
	}

	int i, j;
	struct deaths key;
	for (i = 1; i < num_deaths_rec; i++) 
	{
		key = fatality[i];
		j = i - 1;

		while (j >= 0 && compare_deaths(fatality[j], key) > 0)
		{
			fatality[j + 1] = fatality[j];
			j = j - 1;
		}
		fatality[j + 1] = key;
	}
}

void insert_sort_storms(struct storm_event* storms, int num_storm_rec)
{
	if (tr > 0)
	{
		printf("INSIDE insert_sort_storms:: num_storm_rec : %d\n", num_storm_rec);
	}

	int i, j;
	struct storm_event key;
	for (i = 1; i < num_storm_rec; i++)
	{
		key = storms[i];
		j = i - 1;

		while (j >= 0 && compare_storms(storms[j], key) > 0) {
			storms[j + 1] = storms[j];
			j = j - 1;
		}
		storms[j + 1] = key;
	}
}

void insert_sort_fatality_event(struct fatality_event* fatality, int num_fatality_rec)
{
	if (tr > 0)
	{
		printf("INSIDE insert_sort_fatality_event:: num_fatality_rec : %d\n", num_fatality_rec);
	}

	int i, j;
	struct fatality_event key;
	for (i = 1; i < num_fatality_rec; i++) {
		key = fatality[i];
		j = i - 1;

		while (j >= 0 && compare_fatality(fatality[j], key) > 0) {
			fatality[j + 1] = fatality[j];
			j = j - 1;
		}
		fatality[j + 1] = key;
	}
}

int countLines(char* fileName)
{
	File* fileBuffer;
	int count = 0;
	fileBuffer = fopen(fileName, "rb");

	if (fileBuffer != NULL)
	{
		int a = 0;
		a = getc(fileBuffer);
		while (a != EOF)
		{
			if (a == '\n')
			{
				count++;
			}
			a = getc(fileBuffer);
		}
	}

	fclose(fileBuffer);
	return count;
}

/*loadStormData(char* stormFileName, int count, struct* stormEventsList)
{
	FILE* fileBuffer;

	fileBuffer = fopen(stormFileName, "rb");

	if (fileBuffer != NULL)
	{
		for (int i = 0; i < count; i++)
		{
			if (count != 0)
			{
				stormEventsList[count - 1] = (struct storm_event*)malloc(sizeof(struct storm_event));

				int Tokens = fscanf(fileBuffer, "%c,%d", &stormEventsList[count - 1].event_id, &stormEventsList[count - 1].state, &stormEventsList[count - 1].year, &stormEventsList[count - 1].month_name, &stormEventsList[count - 1].event_type,
					&stormEventsList[count - 1].cz_type, &stormEventsList[count - 1].cz_name, &stormEventsList[count - 1].injuries_direct, &stormEventsList[count - 1].injuries_indirect,
					&stormEventsList[count - 1].deaths_direct, &stormEventsList[count - 1].deaths_indirect, &stormEventsList[count - 1].damage_property, &stormEventsList[count - 1].damage_crops);


				if (Tokens != 13)
				{
					break;
				}
			}

		}
	}

	fclose(fileBuffer);
}*/

void loadStormData(char* stormFileName, int count, struct storm_event stormEventsList[])
{
	if (tr > 0)
	{
		printf("START:: loadStormData :: %d \n", count);
	}

	FILE* fileBuffer;

	fileBuffer = fopen(stormFileName, "rb");
	if (fileBuffer != NULL)
	{
		for (int i = 0; i < count + 1; i++)
		{

			char* linestr = (char*)malloc(1024);
			size_t len = 0;

			getline(&linestr, &len, fileBuffer);

			if (i != 0)
			{
				char* token = strtok(linestr, ",");
				stormEventsList[i - 1].event_id = atoi(token);

				token = strtok(NULL, ",");
				strcpy(stormEventsList[i - 1].state, token);

				token = strtok(NULL, ",");
				stormEventsList[i - 1].year = atoi(token);

				token = strtok(NULL, ",");
				strcpy(stormEventsList[i - 1].month_name, token);

				token = strtok(NULL, ",");
				strcpy(stormEventsList[i - 1].event_type, token);

				token = strtok(NULL, ",");
				stormEventsList[i - 1].cz_type = token[0];

				token = strtok(NULL, ",");
				strcpy(stormEventsList[i - 1].cz_name, token);

				token = strtok(NULL, ",");
				stormEventsList[i - 1].injuries_direct = atoi(token);

				token = strtok(NULL, ",");
				stormEventsList[i - 1].injuries_indirect = atoi(token);

				token = strtok(NULL, ",");
				stormEventsList[i - 1].deaths_direct = atoi(token);

				token = strtok(NULL, ",");
				stormEventsList[i - 1].deaths_indirect = atoi(token);

				token = strtok(NULL, ",");
				stormEventsList[i - 1].damage_property = convertCurrency(token);

				token = strtok(NULL, ",");
				stormEventsList[i - 1].damage_crops = convertCurrency(token);

			}
			if (i == count)
			{
				if (tr > 0)
				{
					printf("free linestr in storm\n");
				}

				free(linestr);
			}
		}
	}
	fclose(fileBuffer);
}

void primary_sort(struct storm_event* storms, int num_storm_rec)
{
	int i, j;
	struct storm_event key;

	for (i = 1; i < num_storm_rec; i++)
	{
		key = storms[i];
		j = i - 1;

		while (j >= 0 && storms[j].event_id > key.event_id) {
			storms[j + 1] = storms[j];
			j = j - 1;
		}
		storms[j + 1] = key;
	}
}

void printStorm_short(struct storm_event* storms, int num_storm_rec)
{
	for (int a = 0; a < num_storm_rec; a++)
	{
		printf("%d ::: %d ::: %d ::: %d\n", storms[a].damage_property, storms[a].year, a, storms[a].event_id);
	}
}

void printStorm(struct storm_event* storms, int num_storm_rec)
{
	int tmp_year;
	if (tr > 0)
	{
		printf("Num of rec to print : %d\n", num_storm_rec);
	}

	for (int i = 0; i < num_storm_rec; i++)
	{
		if (tmp_year != storms[i].year) {
			tmp_year = storms[i].year;
			printf("%d\n", tmp_year);
		}
		printf("	Event Id: %d\n", storms[i].event_id);
		printf("	State: %s\n", storms[i].state);
		printf("	Year: %d\n", storms[i].year);
		printf("	Month: %s\n", storms[i].month_name);
		printf("	Event Type: %s\n", storms[i].event_type);
		printf("	County/Parish/Marine: %c\n", storms[i].cz_type);
		printf("	County/Parish/Marine Name: %s\n", storms[i].cz_name);
		printf("	Injuries Direct: %d\n", storms[i].injuries_direct);
		printf("	Injuries Indirect: %d\n", storms[i].injuries_indirect);
		printf("	Deaths Direct: %d\n", storms[i].deaths_direct);
		printf("	Deaths Indirect: %d\n", storms[i].deaths_indirect);
		printf("	Damage to Property: $%d\n", storms[i].damage_property);
		printf("	Damage to Crops: $%d\n", storms[i].damage_crops);
		printf("\n");
	}
}

void printFatality(struct fatality_event* fatality, int num_fatality_rec)
{
	int tmp_year;
	printf("Num of rec to print : %d\n", num_fatality_rec);
	for (int i = 0; i < num_fatality_rec; i++)
	{

	}
}

/*loadFatalityData(char* fatalityFile, int count, struct* fatalityEventsList)
{
	FILE* fileBuffer;

	fileBuffer = fopen(fatalityFile, "rb");

	if (fileBuffer != NULL)
	{
		for (int i = 0; i < count; i++)
		{
			if (count != 0)
			{
				fatalityEventsList[count - 1] = (struct fatality_event*)malloc(sizeof(struct fatality_event));
				int Tokens = fscanf(fileBuffer, "%c,%d", &fatalityEventsList[count - 1].event_id, &fatalityEventsList[count - 1].fatality_type, &fatalityEventsList[count - 1].fatality_date, &fatalityEventsList[count - 1].fatality_age, &fatalityEventsList[count - 1].fatality_sex,
					&fatalityEventsList[count - 1].fatality_location);

				if (Tokens != 6)
				{
					break;
				}
			}

		}
	}

	fclose(fileBuffer);

}*/

void loadFatalityData(char* fatalityFile, int count, struct fatality_event fatalityEventsList[])
{
	if (tr > 0)
	{
		printf("START loadFatalityData : %s : %d \n", fatalityFile, count);
	}

	FILE* fileBuffer;

	fileBuffer = fopen(fatalityFile, "rb");

	if (fileBuffer != NULL)
	{

		for (int i = 0; i < count + 1; i++)
		{

			char* linestr = (char*)malloc(512);
			size_t leng = 0;
			getline(&linestr, &leng, fileBuffer);


			if (i != 0)
			{


				char* token = strsep(&linestr, ",");
				fatalityEventsList[i - 1].event_id = atoi(token);

				token = strsep(&linestr, ",");
				fatalityEventsList[i - 1].fatality_type = token[0];

				token = strsep(&linestr, ",");
				strcpy(fatalityEventsList[i - 1].fatality_date, token);

				token = strsep(&linestr, ",");
				if (strlen(token) > 0)
				{
					fatalityEventsList[i - 1].fatality_age = atoi(token);
				}
				else
				{
					fatalityEventsList[i - 1].fatality_age = -1;
				}

				token = strsep(&linestr, ",");
				if (strlen(token) > 0)
				{
					fatalityEventsList[i - 1].fatality_sex = token[0];
				}
				else
				{
					fatalityEventsList[i - 1].fatality_sex = 'U';
				}

				token = strsep(&linestr, ",");
				if (strlen(token) > 0)
				{
					strcpy(fatalityEventsList[i - 1].fatality_location, token);
				}
				else
				{
					char* na = "NOT AVAILABLE";
					strcpy(fatalityEventsList[i - 1].fatality_location, na);
				}

			}

			if (i == count) {
				if (tr > 0) printf("free linestr in fatality\n");
				free(linestr);
			}

		}
	}
	fclose(fileBuffer);

}

/*void loadAnualStorm(char* year_str)
{
	char* stormFileName = "data/details-" + year_str + ".csv";
	char* fatalityFileName = "data/fatalities-" + year_str + ".csv";

	int stormEventCount = countLines(stormFileName);
	int fatalityEventCount = countLines(fatalityFileName);
	int noOfStormRec = stormEventCount - 1;
	int noOfFatalityRec = fatalityEventCount - 1;

	struct annual_storm* annualStormTemp;
	struct storm_event stormEventsList[noOfStormRec];
	struct fatality_event fatalityEventsList[noOfFatalityRec];

	annualStormTemp->year = year_str;
	annualStormTemp->no_storms = stormEventCount - 1;
	annualStormTemp->storm_events = stormEventList;
	annualStormTemp->no_fatalities = fatalityEventCount - 1;
	annualStormTemp->fatality_events = fatalityEventsList;


	loadStormData(stormFileName, stormEventCount, stormEventsList);
	loadFatalityData(fatalityFileName, fatalityEventCount, fatalityEventsList);
}*/

void loadAnnualStorm(char* year_str, struct annual_storm* annualStormTemp)
{
	char stormFileName[100] = "data/details-";
	strcat(stormFileName, year_str);
	strcat(stormFileName, ".csv");

	char fatalityFileName[100] = "data/fatalities-";
	strcat(fatalityFileName, year_str);
	strcat(fatalityFileName, ".csv");

	int stormEventCount = countLines(stormFileName);
	int fatalityEventCount = countLines(fatalityFileName);

	if (tr > 0)
	{
		printf("Number of Lines in storm : %d \n", stormEventCount);
	}

	if (tr > 0)
	{
		printf("Number of Lines in fatality : %d \n", fatalityEventCount);
	}

	annualStormTemp->year = atoi(year_str);
	annualStormTemp->no_storms = stormEventCount;
	int noOfStormRec = stormEventCount - 1;

	annualStormTemp->storm_events = (struct storm_event*)malloc(sizeof(struct storm_event*) * noOfStormRec);
	loadStormData(stormFileName, stormEventCount, annualStormTemp->storm_events);

	if (tr > 0)
	{
		printf("annual Storm Data is loaded \n");
	}

	if (tr > 0)
	{
		printf("annual Storm Data is loaded ...2 \n");
	}

	annualStormTemp->no_fatalities = fatalityEventCount;
	int noOfFatalityRec = fatalityEventCount - 1;

	annualStormTemp->fatality_events = (struct fatality_event*)malloc(sizeof(struct fatality_event*) * noOfFatalityRec);
	loadFatalityData(fatalityFileName, fatalityEventCount, annualStormTemp->fatality_events);

	if (tr > 0)
	{
		printf("annual Fatality Data is loaded \n");
	}

	if (tr > 0)
	{
		printf("annual Fatality Data is loaded ...2 \n");
	}
}

int getTotalNoOfRec()
{
	int totalNoOfRec = 0;
	if (tr > 0)
	{
		printf("number of years loaded : %d\n", num_years);
	}

	for (int a = 0; a < num_years; a++)
	{
		if (tr > 0)
		{
			printf("number of record loaded in year %d : %d\n", a, stormList[a].no_storms);
		}

		totalNoOfRec += stormList[a].no_storms;
	}
	return totalNoOfRec;
}

int convertCurrency(char* tok)
{
	int a = 0;
	double d = 0.0;
	char abbr = tok[strlen(tok) - 1];
	if (abbr == 'K')
	{
		d = atof(tok);
		d = d * 1000;
		a = (int)d;
	}

	else if (abbr == 'M')
	{
		d = atof(tok);
		d = d * 1000000;
		a = (int)d;
	}

	else a = atoi(tok);
	return a;
}

void merge_storm(struct storm_event* arrObj, int l, int m, int r)
{
	int i, j, k;
	int n1 = m - l + 1;
	int n2 = r - m;

	struct storm_event* arrObjL = (struct storm_event*)malloc(sizeof(struct storm_event*) * n1);
	struct storm_event* arrObjR = (struct storm_event*)malloc(sizeof(struct storm_event*) * n2);

	for (i = 0; i < n1; i++)
	{
		arrObjL[i] = arrObj[l + i];
	}
	for (j = 0; j < n2; j++)
	{
		arrObjR[j] = arrObj[m + 1 + j];
	}

	i = 0;
	j = 0;
	k = l;

	while (i < n1 && j < n2)
	{
		if (compare_storms(arrObjL[i], arrObjR[j]) > 0)
		{
			arrObj[k] = arrObjL[i];
			i++;
		}
		else
		{
			arrObj[k] = arrObjR[j];
			j++;
		}
		k++;
	}



	while (i < n1)
	{
		arrObj[k] = arrObjL[i];
		i++;
		k++;
	}

	while (j < n2)
	{
		arrObj[k] = arrObjR[j];
		j++;
		k++;
	}
}

void merge_sort_storm(struct storm_event* arrObj, int p, int r)
{
	if (p < r)
	{
		int q = (p + r) / 2;
		merge_sort_storm(arrObj, p, q);
		merge_sort_storm(arrObj, q + 1, r);
		merge_storm(arrObj, p, q, r);
	}

}

void merge_damages(struct damage* arrObj, int l, int m, int r)
{
	int i, j, k;
	int n1 = m - l + 1;
	int n2 = r - m;


	struct damage* arrObjL = (struct damage*)malloc(sizeof(struct damage*) * n1);
	struct damage* arrObjR = (struct damage*)malloc(sizeof(struct damage*) * n2);

	for (i = 0; i < n1; i++)
	{
		arrObjL[i] = arrObj[l + i];
	}
	for (j = 0; j < n2; j++)
	{
		arrObjR[j] = arrObj[m + 1 + j];
	}

	i = 0;
	j = 0;
	k = l;

	while (i < n1 && j < n2)
	{
		if (compare_damages(arrObjL[i], arrObjR[j]) > 0)
		{
			arrObj[k] = arrObjL[i];
			i++;
		}
		else
		{
			arrObj[k] = arrObjR[j];
			j++;
		}
		k++;
	}


	while (i < n1)
	{
		arrObj[k] = arrObjL[i];
		i++;
		k++;
	}

	while (j < n2)
	{
		arrObj[k] = arrObjR[j];
		j++;
		k++;
	}
}

void merge_sort_damages(struct damage* arrObj, int p, int r)
{
	if (p < r)
	{
		int q = (p + r) / 2;
		merge_sort_damages(arrObj, p, q);
		merge_sort_damages(arrObj, q + 1, r);
		merge_damages(arrObj, p, q, r);
	}

}

void merge_fatality(struct deaths* arrObj, int l, int m, int r)
{
	int i, j, k;
	int n1 = m - l + 1;
	int n2 = r - m;

	struct deaths* arrObjL = (struct deaths*)malloc(sizeof(struct deaths*) * n1);
	struct deaths* arrObjR = (struct deaths*)malloc(sizeof(struct deaths*) * n2);

	for (i = 0; i < n1; i++)
	{
		arrObjL[i] = arrObj[l + i];
	}
	for (j = 0; j < n2; j++)
	{
		arrObjR[j] = arrObj[m + 1 + j];
	}

	i = 0;
	j = 0;
	k = l;

	while (i < n1 && j < n2)
	{
		if (compare_deaths(arrObjL[i], arrObjR[j]) > 0)
		{
			arrObj[k] = arrObjL[i];
			i++;
		}
		else
		{
			arrObj[k] = arrObjR[j];
			j++;
		}
		k++;
	}



	while (i < n1)
	{
		arrObj[k] = arrObjL[i];
		i++;
		k++;
	}

	while (j < n2)
	{
		arrObj[k] = arrObjR[j];
		j++;
		k++;
	}
}

void merge_sort_fatality(struct deaths* arrObj, int p, int r)
{
	if (p < r)
	{
		int q = (p + r) / 2;
		merge_sort_fatality(arrObj, p, q);
		merge_sort_fatality(arrObj, q + 1, r);
		merge_fatality(arrObj, p, q, r);
	}

}

void merge_fatality_event(struct fatality_event* arrObj, int l, int m, int r)
{
	int i, j, k;
	int n1 = m - l + 1;
	int n2 = r - m;

	struct fatality_event* arrObjL = (struct fatality_event*)malloc(sizeof(struct fatality_event*) * n1);
	struct fatality_event* arrObjR = (struct fatality_event*)malloc(sizeof(struct fatality_event*) * n2);

	for (i = 0; i < n1; i++)
	{
		arrObjL[i] = arrObj[l + i];
	}
	for (j = 0; j < n2; j++)
	{
		arrObjR[j] = arrObj[m + 1 + j];
	}

	i = 0; // Initial index of first subarray
	j = 0; // Initial index of second subarray
	k = l; // Initial index of merged subarray

	while (i < n1 && j < n2)
	{
		if (compare_fatality(arrObjL[i], arrObjR[j]) > 0)
		{
			arrObj[k] = arrObjL[i];
			i++;
		}
		else
		{
			arrObj[k] = arrObjR[j];
			j++;
		}
		k++;
	}


	while (i < n1)
	{
		arrObj[k] = arrObjL[i];
		i++;
		k++;
	}

	while (j < n2)
	{
		arrObj[k] = arrObjR[j];
		j++;
		k++;
	}
}

void merge_sort_fatality_event(struct fatality_event* arrObj, int p, int r)
{
	if (p < r)
	{
		int q = (p + r) / 2;
		merge_sort_fatality_event(arrObj, p, q);
		merge_sort_fatality_event(arrObj, q + 1, r);
		merge_fatality_event(arrObj, p, q, r);
	}

}

struct fatality_event getFatalityEvent(int event_id, int t_year)
{
	for (int b = 0; b < num_years; b++)
	{
		if (stormList[b].year == t_year) {
			for (int i = 0; i < stormList[b].no_fatalities; i++)
			{
				if (event_id == stormList[b].fatality_events[i].event_id)
				{
					return stormList[b].fatality_events[i];
				}
			}
		}
	}
	struct fatality_event fevent;
	return fevent;
}

/*int main(int Yrs, char* year[])
{
	printf("Enter the number of years: ")

		if (Yrs >= 3)
		{
			printf("The arguments supplied are:\n");

			for (int i = 0; i < Yrs; i++)
			{
				printf("%s\t", year[i]);
			}
		}

		else
		{
			printf("argument list is empty.\n");
		}

	return 0;
}*/

int main(int argc, char* argv[])
{

	if (tr > 0)
	{
		printf("%d parameters are passed \n", argc);
	}

	if (argc > 1)
	{
		if (tr > 0)
		{
			printf("command line parameters are available\n");
		}

		num_years = atoi(argv[1]);
		if (argc < num_years + 2)
		{
			printf("required parameters are not passed\n");
			return 1;
		}
		stormList = (struct annual_storm*)malloc(sizeof(struct annual_storm*) * num_years);
		for (int a = 0; a < num_years; a++)
		{
			loadAnnualStorm(argv[a + 2], &stormList[a]);
			if (tr > 0) printf("number of record loaded in year %d : %d\n", a, stormList[a].no_storms);
			if (tr > 0) printf("first eventId : %d ::: last eventId : %d \n", stormList[a].storm_events[0].event_id, stormList[a].storm_events[stormList[a].no_storms - 1].event_id);
		}
		if (tr > 0)
		{
			printf("data for %d years has been loaded \n", num_years);
		}

		int tot_num_rec = getTotalNoOfRec();
		if (tr > 0)
		{
			printf("Totally %d storm records are loaded\n", tot_num_rec);
		}
		readQuery(stormList);
	}

	return 0;
}
